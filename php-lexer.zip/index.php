<?php

echo "¡¡HOla mundo cruel!, dkdkdk.,.,$$$";

$6fff = 5;

if ($b>0)
{
    $p=1; 
    while($p<=100){
        $q=$q+1;
        $r--;
    }
}
else{
        for($p=0;$p<100; $p++){
            $c=$c+1;
        } 
 /* soy un comentario de varias lineas
  y no me creo mucho*/
    }

$var1 = 5;
$var2 = 1;
echo $var1 > $var2 ? 'var1 es mayor a var2' : 'vaa2 es mayor a var1';
//esto es un comentario alv
?>
